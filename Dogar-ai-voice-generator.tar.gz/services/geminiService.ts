
import { GoogleGenAI, Modality } from "@google/genai";
import { Language } from "../types";

function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

export const refineTextForSpeech = async (text: string, lang: Language): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `You are a professional neural script editor and prosody specialist. 
      TASK: Optimize the text for natural human speech in ${lang}.
      
      EMOTION TAGS: [energetic], [calm], [sad], [loud], [whisper], [angry], [professional].
      
      RULES:
      1. Analyze the context and mood of the text.
      2. Automatically insert the most appropriate emotion tags from the list above at the beginning of sentences or phrases to enhance expression.
      3. Improve prosody, flow, and emotional structure.
      4. OUTPUT ONLY THE FINAL REFINED SCRIPT WITH TAGS. 
      5. DO NOT include any conversational filler, intro, or meta-comments.
      6. If no changes are needed, return the original text exactly.
      
      Script to process: "${text}"`,
      config: { temperature: 0.2 },
    });
    const result = response.text?.trim() || text;
    return result.replace(/^```[\w]*\n/, '').replace(/\n```$/, '');
  } catch (error) {
    console.error("Refinement Error:", error);
    return text;
  }
};

export const generateAudio = async (
  text: string, 
  voiceName: string, 
  isCloned: boolean, 
  referenceAudioBase64?: string
): Promise<Uint8Array | null> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const trimmedText = text.trim();
  if (!trimmedText) throw new Error("Script is empty.");

  const runSynthesis = async () => {
    try {
      if (isCloned && referenceAudioBase64) {
        const response = await ai.models.generateContent({
          model: "gemini-2.5-flash-native-audio-preview-12-2025",
          contents: [
            {
              parts: [
                {
                  inlineData: {
                    data: referenceAudioBase64,
                    mimeType: "audio/wav"
                  }
                },
                {
                  text: `Neural Voice Mimicry Protocol: 
                  Synthesize the following text using the timbre and cadence of the provided reference. 
                  Do not output any text. Output ONLY audio. 
                  Script: "${trimmedText}"`
                }
              ]
            }
          ],
          config: {
            responseModalities: [Modality.AUDIO],
          }
        });
        return extractAudioFromResponse(response);
      } else {
        const response = await ai.models.generateContent({
          model: "gemini-2.5-flash-preview-tts",
          contents: [{ parts: [{ text: trimmedText }] }],
          config: {
            responseModalities: [Modality.AUDIO],
            speechConfig: {
              voiceConfig: {
                prebuiltVoiceConfig: { voiceName: voiceName || 'Zephyr' },
              },
            },
          },
        });
        return extractAudioFromResponse(response);
      }
    } catch (error: any) {
      throw error;
    }
  };

  // Simple retry loop for transient 'OTHER' errors
  let lastError: any = null;
  for (let attempt = 1; attempt <= 2; attempt++) {
    try {
      return await runSynthesis();
    } catch (error: any) {
      lastError = error;
      if (error.message.includes('OTHER') && attempt < 2) {
        console.warn(`Neural Synthesis: Attempt ${attempt} failed with OTHER. Retrying...`);
        await new Promise(resolve => setTimeout(resolve, 1000)); // Short backoff
        continue;
      }
      break;
    }
  }

  console.error("Neural Synthesis Final Error:", lastError);
  throw lastError;
};

function extractAudioFromResponse(response: any): Uint8Array {
  const candidate = response.candidates?.[0];
  
  if (!candidate) {
    throw new Error("Neural output blocked. The request might contain sensitive content or the model is unavailable.");
  }

  if (candidate.finishReason && candidate.finishReason !== 'STOP') {
    if (candidate.finishReason === 'SAFETY') {
      throw new Error("Neural safety interruption. Content flagged for processing.");
    }
    if (candidate.finishReason === 'OTHER') {
       throw new Error("Engine halted: OTHER. This can be caused by long text or transient server load. Please try reducing the text length or retrying.");
    }
    throw new Error(`Engine halted: ${candidate.finishReason}`);
  }

  if (!candidate.content?.parts) {
    throw new Error("Neural stream empty. Please retry the generation.");
  }

  for (const part of candidate.content.parts) {
    if (part.inlineData?.data) {
      return decode(part.inlineData.data);
    }
  }
  
  throw new Error("No audio payload detected in neural response.");
}

export async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number = 24000,
  numChannels: number = 1,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer, data.byteOffset, data.byteLength / 2);
  const frameCount = dataInt16.length / numChannels;
  if (frameCount <= 0) throw new Error("Corrupt audio frames.");
  
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);
  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}
